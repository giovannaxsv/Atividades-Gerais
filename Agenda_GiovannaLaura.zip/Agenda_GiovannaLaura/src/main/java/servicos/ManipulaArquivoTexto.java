/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicos;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.Scanner;
import negocio.Contato;

/**
 *
 * @author giova
 */
public class ManipulaArquivoTexto {
    private File arquivo;
    private Formatter gravador;
    private Scanner leitor;

    public ManipulaArquivoTexto(File arquivo, Formatter gravador, Scanner leitor,String agendaPessoaltxt) {
        this.arquivo = arquivo;
        this.gravador = gravador;
        this.leitor = leitor;
    }

    public ManipulaArquivoTexto(String agendatxt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void abrirArquivoParaGravacao(){
         {
            try
            {
                gravador = new Formatter("AgendaPessoal.txt");
            }
            catch( SecurityException semPermissao)
            {
                System.err.println(" Sem permissao para escrever no arquivo ");
                System.exit(1); //exit(0) é sucesso, outro número significa que terminou com problemas
            }
            catch( FileNotFoundException arquivoInexistente )
            {
                System.err.println(" Arquivo inexistente ou arquivo não pode ser criado");
                System.exit(1);
            }
        } 
    }
    
    public void gravarContato(Contato contato){
        gravador.format("%s;%s;%s;%s\n", contato.getNome(), contato.getEndereco(),contato.getTelefone(),contato.getEmail());
    }    
    
    public void fecharArquivoDeGravacao(){
        gravador.close();
    }
    
    public void abrirArquivoParaLeitura(){
        try {
            leitor = new Scanner(arquivo);
        } catch (FileNotFoundException ex) {
            System.err.println(ex.getMessage());           
        } 
    }
    public void lerArquivo(){
    
    }

}
    

