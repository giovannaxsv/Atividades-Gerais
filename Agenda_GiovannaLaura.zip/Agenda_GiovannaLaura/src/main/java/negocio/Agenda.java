/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;
import java.util.HashMap;
import java.util.Set;
import servicos.ManipulaArquivoTexto;
/**
 *
 * @author giova
 */
public class Agenda {
    private HashMap<String,Contato> agenda;

    public void persistirAgenda(){
        ManipulaArquivoTexto manipular = new ManipulaArquivoTexto("agenda.txt");
    
        Set<String> chaves = agenda.keySet();
        
        chaves.forEach(key -> {
            manipular.gravarContato(agenda.get(key));
        });
    }
}