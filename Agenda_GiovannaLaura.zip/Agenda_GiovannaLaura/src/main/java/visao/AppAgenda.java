/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visao;
import negocio.Contato;
import servicos.ManipulaArquivoTexto;
/**
 *
 * @author giova
 */
public class AppAgenda {
    public static void main(String[] args) {
        Contato contato = new Contato("Giovanna Laura","Rua das Flores","25","giovannalaura.sv@gmail.com");
        ManipulaArquivoTexto manipular = new ManipulaArquivoTexto("agendaPessoal.txt");
        
        manipular.abrirArquivoParaGravacao();
        manipular.gravarContato(contato);
        manipular.fecharArquivoDeGravacao();
    }    
}
